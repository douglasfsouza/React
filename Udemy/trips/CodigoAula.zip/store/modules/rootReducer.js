import { combineReducers } from 'redux';

import reserve from './reserve/reducer';

export default combineReducers({
  reserve,
})